<?php
namespace local_obe\controller;
defined('MOODLE_INTERNAL') || die();
use local_obe\manager\capaian_pembelajaran_manager;

class capaian_pembelajaran_controller {
    public static function get_data($prodi, $angkatan, $courseid) {
        if (empty($prodi) || empty($angkatan) || empty($courseid)) {
            return [];
        }
        return capaian_pembelajaran_manager::ambil_nilai_mahasiswa_per_mata_kuliah($courseid);
    }
}