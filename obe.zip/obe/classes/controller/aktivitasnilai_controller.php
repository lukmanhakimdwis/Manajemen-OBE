<?php
namespace local_obe\controller;
defined('MOODLE_INTERNAL') || die();

use local_obe\manager\aktivitasnilai_manager;

class aktivitasnilai_controller {

    /**
     * Menangani aksi Simpan Mapping Baru.
     */
    public static function eksekusi_simpan($courseid = 0) {
        $cmid        = required_param('cmid', PARAM_INT);
        $sub_cpmk_id = required_param('sub_cpmk_id', PARAM_INT);
        $bobot       = required_param('bobot', PARAM_FLOAT);

        return aktivitasnilai_manager::insert($cmid, $sub_cpmk_id, $bobot, $courseid);
    }

    /**
     * Menangani aksi Update Mapping yang ada.
     */
    public static function eksekusi_update($courseid = 0) {
        $id          = required_param('id', PARAM_INT);
        $sub_cpmk_id = required_param('sub_cpmk_id', PARAM_INT);
        $bobot       = required_param('bobot', PARAM_FLOAT);

        return aktivitasnilai_manager::update($id, $sub_cpmk_id, $bobot, $courseid);
    }

    /**
     * Menangani aksi Hapus Mapping.
     */
    public static function eksekusi_hapus($id) {
        if ($id <= 0) {
            throw new \moodle_exception('invalidparameter', 'error');
        }
        return aktivitasnilai_manager::delete($id);
    }
}
