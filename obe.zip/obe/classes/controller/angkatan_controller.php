<?php
namespace local_obe\controller;
defined('MOODLE_INTERNAL') || die();
use local_obe\manager\angkatan_manager;

class angkatan_controller {
    public static function eksekusi_simpan() {
        $data = new \stdClass();
        $data->id_prodi     = required_param('id_prodi', PARAM_INT);
        $data->tahun_masuk  = required_param('tahun_masuk', PARAM_INT);
        $data->nama_angkatan = required_param('nama_angkatan', PARAM_TEXT);
        $data->status_aktif  = optional_param('status_aktif', 1, PARAM_INT);
        return angkatan_manager::simpan($data);
    }

    public static function eksekusi_update() {
        $data = new \stdClass();
        $data->id           = required_param('id', PARAM_INT);
        $data->id_prodi     = required_param('id_prodi', PARAM_INT);
        $data->tahun_masuk  = required_param('tahun_masuk', PARAM_INT);
        $data->nama_angkatan = required_param('nama_angkatan', PARAM_TEXT);
        $data->status_aktif  = optional_param('status_aktif', 1, PARAM_INT);
        return angkatan_manager::update($data);
    }

    public static function eksekusi_hapus($id) {
        return angkatan_manager::hapus($id);
    }
}