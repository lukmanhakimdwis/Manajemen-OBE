<?php
namespace local_obe\controller;
defined('MOODLE_INTERNAL') || die();
use local_obe\manager\matakuliah_manager;

class matakuliah_controller {
    public static function eksekusi_simpan() {
        $data = new \stdClass();
        $data->id_prodi = required_param('id_prodi', PARAM_INT);
        $data->kode_mk  = required_param('kode_mk', PARAM_TEXT);
        $data->nama_mk  = required_param('nama_mk', PARAM_TEXT);
        $data->sks_mk   = required_param('sks_mk', PARAM_INT);
        return matakuliah_manager::simpan($data);
    }

    public static function eksekusi_update() {
        $data = new \stdClass();
        $data->id       = required_param('id', PARAM_INT);
        $data->id_prodi = required_param('id_prodi', PARAM_INT);
        $data->kode_mk  = required_param('kode_mk', PARAM_TEXT);
        $data->nama_mk  = required_param('nama_mk', PARAM_TEXT);
        $data->sks_mk   = required_param('sks_mk', PARAM_INT);
        return matakuliah_manager::update($data);
    }

    public static function eksekusi_hapus($id) {
        return matakuliah_manager::hapus($id);
    }
}