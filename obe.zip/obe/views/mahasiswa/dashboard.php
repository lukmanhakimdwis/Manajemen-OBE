<?php
// File: /local/obe/views/mahasiswa/dashboard.php

require_once(__DIR__ . '/../../../../config.php');

use local_obe\manager\capaian_pembelajaran_manager;


global $DB, $USER, $SESSION, $OUTPUT, $PAGE, $CFG;

// =====================================================
// PARAMETER (DEFAULT ROUTING TO CPL MODULAR VIEW)
// =====================================================
$courseid = optional_param('id_course', optional_param('id', 0, PARAM_INT), PARAM_INT);
$halaman  = optional_param('halaman', 'cpl', PARAM_ALPHAEXT);

if (empty($courseid)) {
    throw new moodle_exception('Course tidak ditemukan');
}

// =====================================================
// COURSE & CONTEXT
// =====================================================
list($course, $context) = \local_obe\access_guard::require_enrolled_course_user($courseid);

// =====================================================
// PAGE SETUP
// =====================================================
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/obe/views/mahasiswa/dashboard.php', ['id_course' => $courseid, 'halaman' => $halaman]));
$PAGE->set_title('Dashboard Mahasiswa');
$PAGE->set_heading(format_string($course->fullname));

// =====================================================
// RELASI KELAS KURIKULUM
// =====================================================
$relasi = $DB->get_record('local_obe_relasi_kelas', ['id_kursus_moodle' => $courseid]);

if (!$relasi) {
    echo $OUTPUT->header();
    echo $OUTPUT->notification('Kelas belum terhubung OBE', 'error');
    echo $OUTPUT->footer();
    exit;
}

$SESSION->obe_id_tahun_akademik = $relasi->id_tahun_akademik;

// =====================================================
// ADAPTER NILAI MAHASISWA (SHARING VIEW REQUIREMENT)
// =====================================================
if (!function_exists('local_obe_get_nilai_mahasiswa_indikator')) {
    function local_obe_get_nilai_mahasiswa_indikator($courseid, $indikator_id) {
        global $USER, $SESSION;
        return capaian_pembelajaran_manager::ambil_capaian_indikator_per_user(
            $courseid,
            $indikator_id,
            $USER->id,
            $SESSION->obe_id_tahun_akademik ?? 0
        );
    }
}

if (!function_exists('local_obe_get_nilai_mahasiswa_cpmk')) {
    function local_obe_get_nilai_mahasiswa_cpmk($courseid, $cpmk_id) {
        global $USER, $SESSION;

        $list = capaian_pembelajaran_manager::ambil_capaian_cpmk_berdasarkan_cpl(
            $courseid,
            0,
            $USER->id,
            $SESSION->obe_id_tahun_akademik ?? 0
        );

        if (empty($list)) {
            return 0;
        }

        foreach ($list as $item) {
            if (isset($item->cpmk_id) && $item->cpmk_id == $cpmk_id) {
                return $item->nilai_cpmk ?? $item->percentage ?? 0;
            }
        }

        return 0;
    }
}

if (!function_exists('local_obe_get_nilai_mahasiswa_subcpmk')) {
    function local_obe_get_nilai_mahasiswa_subcpmk($courseid, $subcpmk_id) {
        global $USER;

        $detail = capaian_pembelajaran_manager::ambil_detail_data_mahasiswa_obe($courseid, $subcpmk_id);

        if (empty($detail) || empty($detail->users)) {
            return 0;
        }

        foreach ($detail->users as $mhs) {
            $userid = $mhs->userid ?? $mhs->id ?? 0;

            if ($userid == $USER->id) {
                return $mhs->total_nilai_obe ?? $mhs->percentage ?? 0;
            }
        }

        return 0;
    }
}

// =====================================================
// ROUTING SUBPAGE OUTPUT BUFFERING
// =====================================================
ob_start();
$mode_view = 'mahasiswa';

switch ($halaman) {
    case 'beranda':
    case 'cpl':
        include($CFG->dirroot . '/local/obe/views/admin/capaian_kelas/list_cpl.php');
        break;

    case 'indikator':
        include($CFG->dirroot . '/local/obe/views/admin/capaian_kelas/list_indikator.php');
        break;

    case 'cpmk':
        include($CFG->dirroot . '/local/obe/views/admin/capaian_kelas/list_cpmk.php');
        break;

    case 'subcpmk':
        include($CFG->dirroot . '/local/obe/views/admin/capaian_kelas/list_subcpmk.php');
        break;

    case 'detail_mahasiswa':
        include($CFG->dirroot . '/local/obe/views/admin/capaian_kelas/detail_nilai_subcpmk.php');
        break;
}
$content = ob_get_clean();

// =====================================================
// UNIFIED OUTPUT RENDERING
// =====================================================
echo $OUTPUT->header();

if (!empty($content)) {
    echo $content;
}

echo $OUTPUT->footer();
return;